/*
  # Create Service Requests Table for VVS Computers

  1. New Tables
    - `service_requests`
      - `id` (uuid, primary key)
      - `name` (text, customer name)
      - `email` (text, customer email)
      - `phone` (text, customer phone)
      - `device` (text, type of device - laptop/desktop/monitor)
      - `issue` (text, type of issue reported)
      - `message` (text, additional details)
      - `status` (text, request status - pending/assigned/in-progress/completed)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `service_requests` table
    - Add policy for public INSERT (customers can submit requests)
    - Add policy for service provider to read all requests
*/

CREATE TABLE IF NOT EXISTS service_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  device text NOT NULL,
  issue text NOT NULL,
  message text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'in-progress', 'completed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE service_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit service requests"
  ON service_requests
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view all service requests"
  ON service_requests
  FOR SELECT
  TO anon, authenticated
  USING (true);
