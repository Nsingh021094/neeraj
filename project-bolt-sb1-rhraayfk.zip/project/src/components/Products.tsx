import { Mouse, Keyboard, HardDrive, Smartphone, Monitor, MemoryStick, Package } from 'lucide-react';

const products = [
  {
    icon: Mouse,
    title: 'Gaming & Wireless Mouse',
    description: 'High-precision gaming mice and ergonomic wireless mice from top brands'
  },
  {
    icon: Keyboard,
    title: 'Mechanical Keyboards',
    description: 'Mechanical gaming keyboards and office keyboards with various switches'
  },
  {
    icon: HardDrive,
    title: 'SSD Drives',
    description: 'Fast NVMe and SATA SSDs for laptop and desktop upgrades'
  },
  {
    icon: MemoryStick,
    title: 'Pen Drives & Storage',
    description: 'USB pen drives and external storage solutions up to 2TB capacity'
  },
  {
    icon: Smartphone,
    title: 'Laptops',
    description: 'Dell, HP, Lenovo, Asus, and Acer laptops with warranty support'
  },
  {
    icon: Package,
    title: 'Desktop Computers',
    description: 'Custom built and branded desktop PCs for gaming and office work'
  },
  {
    icon: Monitor,
    title: 'Monitors & Displays',
    description: '24" to 32" monitors - 1080p, 2K, and 4K resolution displays'
  },
  {
    icon: MemoryStick,
    title: 'RAM & Memory',
    description: 'DDR3, DDR4, DDR5 RAM modules from 4GB to 32GB capacity'
  }
];

export default function Products() {
  return (
    <section id="products" className="py-20 bg-gradient-to-b from-slate-900 to-slate-800">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Premium Tech Products</h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Quality hardware components and devices available for purchase or upgrade
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-slate-800 to-slate-700 p-6 rounded-xl hover:shadow-2xl hover:shadow-blue-500/20 transition transform hover:-translate-y-2 border border-slate-700 hover:border-blue-500"
            >
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 w-14 h-14 rounded-lg flex items-center justify-center mb-4 group-hover:shadow-lg group-hover:shadow-blue-500">
                <product.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">{product.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{product.description}</p>
              <button
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="mt-4 text-blue-400 hover:text-blue-300 text-sm font-semibold transition"
              >
                Inquire Now →
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800 rounded-2xl p-8 md:p-12 text-white">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-3xl font-bold mb-2">Need Specific Components?</h3>
              <p className="text-blue-100 text-lg">We source genuine parts and provide warranty on all products</p>
            </div>
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-slate-100 transition shadow-lg whitespace-nowrap"
            >
              Place an Order
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
