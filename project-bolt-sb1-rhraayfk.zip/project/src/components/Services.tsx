import { Cpu, HardDrive, Monitor, Battery, Wifi, Wrench, Zap, Shield } from 'lucide-react';

const services = [
  {
    icon: Cpu,
    title: 'Motherboard Repair',
    description: 'Expert motherboard diagnosis and repair for all laptop and desktop computers.'
  },
  {
    icon: Monitor,
    title: 'Screen Replacement',
    description: 'Cracked or damaged screens replaced with quality displays for laptops and monitors.'
  },
  {
    icon: Battery,
    title: 'Battery Replacement',
    description: 'Genuine battery replacements to restore your device\'s power and performance.'
  },
  {
    icon: Wrench,
    title: 'Keyboard Repair',
    description: 'Fix sticky keys, replace damaged keyboards, and restore full functionality.'
  },
  {
    icon: HardDrive,
    title: 'Storage Upgrade',
    description: 'SSD and HDD replacement or upgrade for increased storage and faster boot times.'
  },
  {
    icon: Wifi,
    title: 'Network Issues',
    description: 'Repair WiFi cards, network adapters, and connectivity problems.'
  },
  {
    icon: Zap,
    title: 'Power Issues',
    description: 'Fix charging ports, power supply problems, and all power-related issues.'
  },
  {
    icon: Shield,
    title: 'Hardware Replacement',
    description: 'Any damaged or faulty hardware replaced with quality components.'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Expert Repair Services</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Professional solutions for all your computer and laptop repair needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-white p-6 rounded-xl hover:shadow-2xl transition transform hover:-translate-y-2 border-2 border-gray-100 hover:border-blue-500"
            >
              <div className="bg-gradient-to-br from-blue-100 to-blue-50 w-14 h-14 rounded-lg flex items-center justify-center mb-4 group-hover:from-blue-600 group-hover:to-blue-700 transition">
                <service.icon className="w-7 h-7 text-blue-600 group-hover:text-white transition" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-white hover:shadow-xl transition">
            <h3 className="text-2xl font-bold mb-2">Pick & Drop Service</h3>
            <p className="text-blue-100">Free pickup and delivery in Ghaziabad area</p>
          </div>
          <div className="bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl p-8 text-white hover:shadow-xl transition">
            <h3 className="text-2xl font-bold mb-2">Payment Options</h3>
            <p className="text-emerald-100">Cash on Delivery & Online Payment</p>
          </div>
          <div className="bg-gradient-to-br from-cyan-600 to-cyan-700 rounded-2xl p-8 text-white hover:shadow-xl transition">
            <h3 className="text-2xl font-bold mb-2">Expert Support</h3>
            <p className="text-cyan-100">Professional technicians with experience</p>
          </div>
        </div>

        <div className="mt-8 text-center">
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-10 py-4 rounded-lg font-semibold hover:shadow-lg hover:shadow-blue-500/50 transition"
          >
            Request a Service
          </button>
        </div>
      </div>
    </section>
  );
}
