import { Wrench, Clock, CheckCircle } from 'lucide-react';

export default function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="pt-32 pb-20 bg-gradient-to-br from-slate-950 via-slate-900 to-blue-900">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Professional Tech Repair & Parts
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-8 leading-relaxed">
              Expert laptop and computer repair, motherboard diagnostics, hardware upgrades, and genuine tech components. Serving Ghaziabad with quality service and competitive pricing.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button onClick={scrollToContact} className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:shadow-xl hover:shadow-blue-500/50 transition shadow-lg transform hover:-translate-y-1">
                Request Service
              </button>
              <button onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })} className="bg-slate-700 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-slate-600 transition border-2 border-slate-600">
                Browse Products
              </button>
            </div>

            <div className="grid grid-cols-3 gap-6 mt-12">
              <div className="flex flex-col items-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <Wrench className="w-10 h-10 text-blue-400 mb-2" />
                <p className="text-2xl font-bold text-white">500+</p>
                <p className="text-sm text-slate-400">Repairs Done</p>
              </div>
              <div className="flex flex-col items-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <Clock className="w-10 h-10 text-blue-400 mb-2" />
                <p className="text-2xl font-bold text-white">24hr</p>
                <p className="text-sm text-slate-400">Quick Service</p>
              </div>
              <div className="flex flex-col items-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <CheckCircle className="w-10 h-10 text-blue-400 mb-2" />
                <p className="text-2xl font-bold text-white">100%</p>
                <p className="text-sm text-slate-400">Satisfaction</p>
              </div>
            </div>
          </div>

          <div className="flex-1">
            <img
              src="https://images.pexels.com/photos/4792728/pexels-photo-4792728.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Computer Repair"
              className="rounded-2xl shadow-2xl w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
