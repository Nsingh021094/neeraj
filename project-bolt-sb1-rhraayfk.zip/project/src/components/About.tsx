import { Award, Users, Clock, ThumbsUp } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: Award,
      title: 'Expert Technicians',
      description: 'Professional technicians specializing in laptop and motherboard repairs'
    },
    {
      icon: ThumbsUp,
      title: 'Quality Service',
      description: 'High-quality replacement parts and professional repair workmanship'
    },
    {
      icon: Clock,
      title: 'Quick Turnaround',
      description: 'Fast repair service with minimal downtime for your device'
    },
    {
      icon: Users,
      title: 'Customer Friendly',
      description: 'Free pickup and drop service in Ghaziabad area with flexible payments'
    }
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Why Choose VVS Computers?
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              VVS Computers is your trusted partner for all laptop and computer repair needs in Ghaziabad. We specialize in motherboard repair, hardware replacement, and comprehensive device servicing.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              With our convenient pick & drop service, professional technicians, and flexible payment options, we make getting your device repaired simple and stress-free.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div key={index} className="flex gap-4">
                  <div className="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-1">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Technician at work"
              className="rounded-2xl shadow-2xl w-full"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-xl max-w-xs">
              <p className="text-3xl font-bold text-blue-600 mb-1">100% Satisfied</p>
              <p className="text-gray-700">Customer Commitment</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
