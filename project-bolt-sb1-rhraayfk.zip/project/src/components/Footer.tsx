import { Laptop, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Laptop className="w-8 h-8 text-blue-400" />
              <span className="text-2xl font-bold">VVS Computers</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Professional laptop and computer repair services in Ghaziabad with pick & drop facility.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><button onClick={() => document.getElementById('home')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-400 hover:text-white transition">Home</button></li>
              <li><button onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-400 hover:text-white transition">Services</button></li>
              <li><button onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-400 hover:text-white transition">About</button></li>
              <li><button onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })} className="text-gray-400 hover:text-white transition">Contact</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Our Services</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Motherboard Repair</li>
              <li>Screen Replacement</li>
              <li>Keyboard Repair</li>
              <li>Hardware Upgrade</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Phone: +91 99114 39688</li>
              <li>WhatsApp Available</li>
              <li>Email: chaudharyneeraj002@gmail.com</li>
              <li>Ghaziabad, UP</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>&copy; 2024 VVS Computers. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
