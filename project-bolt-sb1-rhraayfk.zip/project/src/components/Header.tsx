import { Laptop, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-gradient-to-r from-slate-950 to-slate-900 shadow-xl fixed w-full top-0 z-50 border-b border-slate-800">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('home')}>
            <Laptop className="w-8 h-8 text-blue-400" />
            <span className="text-2xl font-bold text-white">VVS Computers</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => scrollToSection('home')} className="text-slate-300 hover:text-blue-400 transition">Home</button>
            <button onClick={() => scrollToSection('services')} className="text-slate-300 hover:text-blue-400 transition">Services</button>
            <button onClick={() => scrollToSection('products')} className="text-slate-300 hover:text-blue-400 transition">Products</button>
            <button onClick={() => scrollToSection('about')} className="text-slate-300 hover:text-blue-400 transition">About</button>
            <button onClick={() => scrollToSection('contact')} className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-2 rounded-lg hover:shadow-lg hover:shadow-blue-500/50 transition">Contact Us</button>
          </div>

          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-slate-700 pt-4">
            <div className="flex flex-col gap-4">
              <button onClick={() => scrollToSection('home')} className="text-slate-300 hover:text-blue-400 transition text-left">Home</button>
              <button onClick={() => scrollToSection('services')} className="text-slate-300 hover:text-blue-400 transition text-left">Services</button>
              <button onClick={() => scrollToSection('products')} className="text-slate-300 hover:text-blue-400 transition text-left">Products</button>
              <button onClick={() => scrollToSection('about')} className="text-slate-300 hover:text-blue-400 transition text-left">About</button>
              <button onClick={() => scrollToSection('contact')} className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-2 rounded-lg hover:shadow-lg hover:shadow-blue-500/50 transition">Contact Us</button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
